from capytale.autoeval import (
    ValidateVariables,
    ValidateFunction,
    ValidateFunctionPretty,
    validationclass
)
from itertools import product

# contenu du fichier _validation.py
from capytale.autoeval import Validate

cellule_import = Validate()
# c'est cet appel qui aura pour effet de valider la cellule d'import
cellule_import()

@validationclass
class LitValidate:
    def __init__(self):
        pass

    def __call__(self):
        # lecture de _validation.txt
        resultat = 0
        try :
            with open("validation.txt","r") as f:
                resultat = int(f.readline())
        except:
            print("Vous devez exécuter l'exercice ci-dessus avant de continuer")
            return 
        if resultat == 1:
            # on remet la validatin à 0 en vue du prochain exercice
            with open("validation.txt","w") as f:
                f.write("0")
            return True
        else:
            print("Vous n'avez pas validé la bonne réponse")
            return False

continuer_1 = LitValidate()
continuer_2 = LitValidate()
continuer_3 = LitValidate()
continuer_4 = LitValidate()
continuer_5 = ValidateVariables({"correct": 1})
continuer_6 = ValidateVariables({"correct": 1})