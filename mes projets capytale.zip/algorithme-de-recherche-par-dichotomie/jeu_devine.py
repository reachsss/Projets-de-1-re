from random import randint
  
def devine():
    nb = randint(1,101)
    coups = 0
    trouve = False
    print('Un nombre a été choisi au hasard entre 1 et 100. À toi de le trouver ! (en moins de 12 coups)')
    message ="C'est parti!"
    while coups<13 and not(trouve):
        coups += 1
        val = 0
        while not(isinstance(val,int)) or not(0<val<101):
            rep = input(message+"Quel nombre proposes-tu ?")
            val = int(rep)
            if val == nb:
                trouve = True
            elif val < nb:
                print("Pas assez !")
                message = "pas assez !"
            else:
                print("C'est trop !")
                message = "c'est trop !"
    if trouve:
        print("Bravo ! tu as trouvé",nb,"en",coups,"tentatives")
    else:
        print("Perdu, c'était",nb)
    return coups

def jeu(parties):
    assert(parties>0)
    assert(type(parties)==int)
    total = 0
    for k in range(parties):
        total = total + devine()
    return total/parties
        