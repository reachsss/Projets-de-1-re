def autant(liste : list) -> bool :
    ''' renvoie un booleen qui indique si la liste comporte autant de 0 que de 1'''
    z,u = 0,0
    for e in liste:
        if e == 0:
            z = z+1
        if e == 1:
            u = u+1
    return u == z
    
    
def identiques(tab1,tab2) -> bool:
    ''' renvoie un booleen indiquant si les deux listes sont identiques (même taille, même élément)'''
    assert len(tab1)==len(tab2),'listes de tailles différentes'
    return tab1 == tab2
    
    
def triplet(liste : list, symbole : int) -> bool :
    ''' renvoie un booleen qui indique si la liste comporte trois symboles à la suite '''
    for k in range(len(liste)-2):
        if liste[k] == liste[k+1] == liste[k+2] == symbole:
            return True
    return False
